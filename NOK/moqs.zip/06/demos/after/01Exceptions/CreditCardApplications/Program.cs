﻿using System;

namespace CreditCardApplications
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Processing...");
            Console.ReadLine();
        }
    }
}
